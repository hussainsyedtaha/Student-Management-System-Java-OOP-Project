import java.io.*;
import java.util.*;

public class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();
    private final String FILE_NAME = "students.txt";

    public void loadFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 4) {
                    students.add(new Student(data[0], data[1], Integer.parseInt(data[2]), data[3]));
                }
            }
        } catch (IOException e) {
            System.out.println("No existing file found. Starting fresh.");
        }
    }

    public void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Student s : students) {
                bw.write(s.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving file.");
        }
    }

    public void addStudent(Student s) {
        students.add(s);
        System.out.println("✓ Student added successfully!");
    }

    public void viewAll() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }
        for (Student s : students) {
            System.out.println("ID: " + s.getId() + ", Name: " + s.getName() +
                               ", Age: " + s.getAge() + ", Grade: " + s.getGrade());
        }
    }

    public void searchStudent(String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                System.out.println("Found: " + s.getName() + " (" + s.getGrade() + ")");
                return;
            }
        }
        System.out.println("✗ Student not found.");
    }

    public void deleteStudent(String id) {
        students.removeIf(s -> s.getId().equalsIgnoreCase(id));
        System.out.println("🗑 Student deleted (if existed).");
    }
}
